import React from 'react';
import { Link } from 'react-router-dom';
import { Bus, Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-100 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 pt-12 pb-8">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Bus className="h-6 w-6 text-primary-600 dark:text-primary-500" />
              <span className="text-xl font-bold text-primary-800 dark:text-primary-400">RideEase</span>
            </div>
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              Making bus travel easy, comfortable, and accessible for everyone. Book your journey with confidence.
            </p>
            <div className="flex space-x-4 pt-2">
              <a href="#" className="text-gray-500 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500">
                <Facebook size={20} />
                <span className="sr-only">Facebook</span>
              </a>
              <a href="#" className="text-gray-500 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500">
                <Twitter size={20} />
                <span className="sr-only">Twitter</span>
              </a>
              <a href="#" className="text-gray-500 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500">
                <Instagram size={20} />
                <span className="sr-only">Instagram</span>
              </a>
              <a href="#" className="text-gray-500 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500">
                <Linkedin size={20} />
                <span className="sr-only">LinkedIn</span>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-gray-900 dark:text-gray-100">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-600 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500 text-sm">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/routes" className="text-gray-600 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500 text-sm">
                  Routes
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-gray-600 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500 text-sm">
                  Services
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-600 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500 text-sm">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-600 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500 text-sm">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-gray-900 dark:text-gray-100">Our Services</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/services" className="text-gray-600 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500 text-sm">
                  Express Routes
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-gray-600 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500 text-sm">
                  Luxury Buses
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-gray-600 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500 text-sm">
                  City Tours
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-gray-600 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500 text-sm">
                  Group Bookings
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-gray-600 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500 text-sm">
                  Corporate Travel
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-gray-900 dark:text-gray-100">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-start space-x-3">
                <MapPin size={18} className="text-primary-600 dark:text-primary-500 flex-shrink-0 mt-0.5" />
                <span className="text-gray-600 dark:text-gray-400 text-sm">
                  123 Travel Street, Downtown<br />New York, NY 10001
                </span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone size={18} className="text-primary-600 dark:text-primary-500" />
                <a href="tel:+123456789" className="text-gray-600 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500 text-sm">
                  +1 (234) 567-8900
                </a>
              </li>
              <li className="flex items-center space-x-3">
                <Mail size={18} className="text-primary-600 dark:text-primary-500" />
                <a href="mailto:info@rideease.com" className="text-gray-600 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500 text-sm">
                  info@rideease.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-200 dark:border-gray-800 mt-10 pt-6">
          <div className="flex flex-col sm:flex-row justify-between items-center">
            <p className="text-sm text-gray-500 dark:text-gray-400">
              &copy; {new Date().getFullYear()} RideEase. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-3 sm:mt-0">
              <Link to="/terms" className="text-sm text-gray-500 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500">
                Terms of Service
              </Link>
              <Link to="/privacy" className="text-sm text-gray-500 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500">
                Privacy Policy
              </Link>
              <Link to="/faq" className="text-sm text-gray-500 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-500">
                FAQ
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;