import React from 'react';
import { QrCode, ArrowDown } from 'lucide-react';

const AppCTA: React.FC = () => {
  return (
    <section className="py-16 bg-white dark:bg-gray-900">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          <div className="order-2 lg:order-1">
            <div className="max-w-lg">
              <h2 className="mb-4 text-gray-900 dark:text-white">Download Our Mobile App</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                Get the best experience with our mobile app. Book tickets, receive instant updates, and manage your journeys on the go.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <a 
                  href="#" 
                  className="inline-flex items-center justify-center h-14 px-6 rounded-lg bg-black text-white hover:bg-gray-900 transition-colors"
                >
                  <div className="mr-3">
                    <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" strokeWidth="2" fill="none">
                      <path d="M12 18.178C12 18.178 20 14.142 20 10.001C20 6.667 16.418 4 12 4C7.582 4 4 6.667 4 10.001C4 14.142 12 18.178 12 18.178Z" />
                    </svg>
                  </div>
                  <div className="text-left">
                    <div className="text-xs">Download on the</div>
                    <div className="text-sm font-semibold">App Store</div>
                  </div>
                </a>
                
                <a 
                  href="#" 
                  className="inline-flex items-center justify-center h-14 px-6 rounded-lg bg-black text-white hover:bg-gray-900 transition-colors"
                >
                  <div className="mr-3">
                    <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" strokeWidth="2" fill="none">
                      <polygon points="3 3 21 12 3 21 3 3" />
                    </svg>
                  </div>
                  <div className="text-left">
                    <div className="text-xs">GET IT ON</div>
                    <div className="text-sm font-semibold">Google Play</div>
                  </div>
                </a>
              </div>
              
              <div className="flex items-center space-x-6">
                <div className="p-3 bg-gray-100 dark:bg-gray-800 rounded-lg">
                  <QrCode size={64} className="text-gray-800 dark:text-gray-200" />
                </div>
                <div>
                  <p className="font-medium text-gray-900 dark:text-white mb-1">Scan to download</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Point your camera at the QR code to download our app.
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="order-1 lg:order-2 flex justify-center">
            <div className="relative">
              {/* Phone mockup */}
              <div className="w-64 h-[500px] bg-gray-900 rounded-[40px] border-[14px] border-gray-900 overflow-hidden shadow-xl">
                <div className="absolute top-0 left-0 right-0 h-6 bg-gray-900 z-10 flex justify-center">
                  <div className="w-24 h-4 bg-gray-900 rounded-b-lg" />
                </div>
                {/* App Screen */}
                <div className="h-full bg-white overflow-hidden relative">
                  <div className="h-40 bg-primary-600 p-4 flex flex-col justify-end">
                    <h3 className="text-white text-lg font-bold">RideEase</h3>
                    <p className="text-primary-100 text-sm">Your journey starts here</p>
                  </div>
                  <div className="p-4">
                    <div className="bg-white rounded-lg shadow-md p-3 -mt-16 mb-4">
                      <p className="text-xs text-gray-500 mb-1">Popular Route</p>
                      <div className="flex justify-between items-center mb-2">
                        <p className="font-medium">New York</p>
                        <ArrowDown className="rotate-90 w-4 h-4 text-gray-400" />
                        <p className="font-medium">Boston</p>
                      </div>
                      <div className="flex justify-between text-xs">
                        <p>Today, 10:00 AM</p>
                        <p className="font-bold text-primary-600">$45</p>
                      </div>
                    </div>
                    
                    <p className="text-xs font-medium text-gray-500 uppercase mb-2">Quick Actions</p>
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      {["Book", "My Tickets", "Support"].map((action, i) => (
                        <div key={i} className="bg-gray-100 rounded-lg p-3 flex flex-col items-center">
                          <div className="w-6 h-6 bg-primary-100 rounded-full mb-1 flex items-center justify-center">
                            <div className="w-3 h-3 bg-primary-600 rounded-full" />
                          </div>
                          <p className="text-xs">{action}</p>
                        </div>
                      ))}
                    </div>
                    
                    <p className="text-xs font-medium text-gray-500 uppercase mb-2">Upcoming Trips</p>
                    {[1, 2].map((trip) => (
                      <div key={trip} className="bg-gray-50 rounded-lg p-3 mb-2">
                        <div className="flex justify-between mb-1">
                          <p className="text-xs font-medium">Trip #{trip}0{Math.floor(Math.random() * 99)}</p>
                          <p className="text-xs text-primary-600 font-medium">Confirmed</p>
                        </div>
                        <div className="border-b border-dashed border-gray-200 pb-2 mb-2" />
                        <div className="flex justify-between text-xs">
                          <p>Oct {10 + trip}, 2023</p>
                          <p>Seat: 1{trip}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              
              {/* Decorative elements */}
              <div className="absolute -bottom-6 -left-6 w-40 h-40 bg-primary-200 dark:bg-primary-900/30 rounded-full blur-3xl opacity-40 -z-10" />
              <div className="absolute -top-6 -right-6 w-40 h-40 bg-teal-200 dark:bg-teal-900/30 rounded-full blur-3xl opacity-40 -z-10" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AppCTA;