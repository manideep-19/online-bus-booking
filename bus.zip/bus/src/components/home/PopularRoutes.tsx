import React from 'react';
import { ArrowRight, Navigation } from 'lucide-react';
import { Link } from 'react-router-dom';

interface RouteCardProps {
  from: string;
  to: string;
  price: number;
  duration: string;
  image: string;
}

const RouteCard: React.FC<RouteCardProps> = ({ from, to, price, duration, image }) => {
  return (
    <div className="card overflow-hidden group">
      <div className="h-48 overflow-hidden relative">
        <img 
          src={image} 
          alt={`${from} to ${to}`}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
          <div className="p-4 text-white">
            <p className="text-sm font-medium opacity-90">Starting from</p>
            <p className="text-xl font-bold">${price}</p>
          </div>
        </div>
      </div>
      
      <div className="p-5">
        <div className="flex items-center mb-3">
          <div className="flex-1 space-y-1">
            <div className="flex items-center">
              <Navigation size={16} className="text-primary-600 dark:text-primary-500 mr-2" />
              <p className="font-medium text-gray-900 dark:text-white">{from}</p>
            </div>
          </div>
          
          <ArrowRight size={18} className="mx-2 text-gray-400" />
          
          <div className="flex-1 space-y-1">
            <div className="flex items-center">
              <Navigation size={16} className="text-primary-600 dark:text-primary-500 mr-2" />
              <p className="font-medium text-gray-900 dark:text-white">{to}</p>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between items-center">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            {duration}
          </p>
          <Link
            to={`/search?from=${from}&to=${to}`}
            className="btn btn-sm btn-secondary"
          >
            Check Availability
          </Link>
        </div>
      </div>
    </div>
  );
};

const PopularRoutes: React.FC = () => {
  const routes = [
    {
      from: "Mumbai",
      to: "Pune",
      price: 450,
      duration: "3h 30m",
      image: "https://images.pexels.com/photos/2901209/pexels-photo-2901209.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750"
    },
    {
      from: "Delhi",
      to: "Agra",
      price: 550,
      duration: "4h 15m",
      image: "https://images.pexels.com/photos/2068412/pexels-photo-2068412.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750"
    },
    {
      from: "Bangalore",
      to: "Mysore",
      price: 400,
      duration: "3h 45m",
      image: "https://images.pexels.com/photos/208745/pexels-photo-208745.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750"
    },
    {
      from: "Chennai",
      to: "Pondicherry",
      price: 350,
      duration: "3h 15m",
      image: "https://images.pexels.com/photos/290386/pexels-photo-290386.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750"
    }
  ];

  return (
    <section className="py-16 bg-white dark:bg-gray-900">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="mb-4 text-gray-900 dark:text-white">Popular Routes</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Discover our most traveled routes with the best prices and frequent departures.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {routes.map((route, index) => (
            <RouteCard
              key={index}
              from={route.from}
              to={route.to}
              price={route.price}
              duration={route.duration}
              image={route.image}
            />
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Link to="/routes" className="btn btn-lg btn-primary">
            View All Routes
          </Link>
        </div>
      </div>
    </section>
  );
};

export default PopularRoutes;