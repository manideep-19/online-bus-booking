import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CornerDownRight, CalendarDays } from 'lucide-react';
import { getNextFifteenDays } from '../../lib/utils';

interface City {
  id: string;
  name: string;
}

const popularCities: City[] = [
  { id: '1', name: 'Mumbai' },
  { id: '2', name: 'Delhi' },
  { id: '3', name: 'Bangalore' },
  { id: '4', name: 'Chennai' },
  { id: '5', name: 'Kolkata' },
  { id: '6', name: 'Hyderabad' },
  { id: '7', name: 'Pune' },
  { id: '8', name: 'Ahmedabad' },
  { id: '9', name: 'Jaipur' },
  { id: '10', name: 'Kochi' },
];

const HeroSection: React.FC = () => {
  const [fromCity, setFromCity] = useState<string>('');
  const [toCity, setToCity] = useState<string>('');
  const [departureDate, setDepartureDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [showFromDropdown, setShowFromDropdown] = useState<boolean>(false);
  const [showToDropdown, setShowToDropdown] = useState<boolean>(false);
  const [showCalendar, setShowCalendar] = useState<boolean>(false);
  const navigate = useNavigate();

  const filteredFromCities = popularCities.filter(city => 
    city.name.toLowerCase().includes(fromCity.toLowerCase())
  );
  
  const filteredToCities = popularCities.filter(city => 
    city.name.toLowerCase().includes(toCity.toLowerCase()) && city.name !== fromCity
  );

  const nextFifteenDays = getNextFifteenDays();

  const handleSwapCities = () => {
    const temp = fromCity;
    setFromCity(toCity);
    setToCity(temp);
  };

  const handleSearch = () => {
    if (fromCity && toCity && departureDate) {
      navigate('/search', { 
        state: { 
          fromCity, 
          toCity, 
          departureDate 
        } 
      });
    }
  };

  const handleFromCitySelect = (city: string) => {
    setFromCity(city);
    setShowFromDropdown(false);
  };

  const handleToCitySelect = (city: string) => {
    setToCity(city);
    setShowToDropdown(false);
  };

  const handleDateSelect = (date: Date) => {
    setDepartureDate(date.toISOString().split('T')[0]);
    setShowCalendar(false);
  };

  return (
    <section className="relative overflow-hidden">
      {/* Background image with overlay */}
      <div className="absolute inset-0 bg-hero-pattern bg-cover bg-center">
        <div className="absolute inset-0 bg-gradient-to-r from-primary-900/80 to-primary-800/70" />
      </div>
      
      <div className="container relative z-10 py-16 md:py-24 lg:py-32">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-10">
            <h1 className="text-white mb-4 font-bold animate-fade-in">
              Your Journey, Our Priority
            </h1>
            <p className="text-primary-100 text-lg md:text-xl max-w-xl mx-auto animate-slide-up">
              Book comfortable and reliable bus tickets to your favorite destinations at the best prices.
            </p>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl overflow-hidden animate-slide-up">
            <div className="p-6">
              <div className="flex flex-col space-y-4">
                <div className="flex flex-col lg:flex-row gap-4">
                  {/* From Location */}
                  <div className="flex-1 relative">
                    <label htmlFor="from-location" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      From
                    </label>
                    <input
                      id="from-location"
                      type="text"
                      placeholder="Enter departure city"
                      className="input"
                      value={fromCity}
                      onChange={(e) => {
                        setFromCity(e.target.value);
                        setShowFromDropdown(true);
                      }}
                      onFocus={() => setShowFromDropdown(true)}
                    />
                    {showFromDropdown && (
                      <div className="absolute z-10 w-full mt-1 bg-white dark:bg-gray-800 rounded-md shadow-lg max-h-60 overflow-auto">
                        {filteredFromCities.length > 0 ? (
                          filteredFromCities.map((city) => (
                            <div
                              key={city.id}
                              className="px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-primary-50 dark:hover:bg-gray-700 cursor-pointer"
                              onClick={() => handleFromCitySelect(city.name)}
                            >
                              {city.name}
                            </div>
                          ))
                        ) : (
                          <div className="px-4 py-2 text-sm text-gray-500 dark:text-gray-400">
                            No cities found
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  
                  {/* Swap Button */}
                  <div className="hidden lg:flex items-center justify-center self-end mb-1">
                    <button
                      type="button"
                      onClick={handleSwapCities}
                      className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600"
                      aria-label="Swap cities"
                    >
                      <CornerDownRight size={18} className="text-gray-600 dark:text-gray-300 transform rotate-90" />
                    </button>
                  </div>
                  
                  {/* To Location */}
                  <div className="flex-1 relative">
                    <label htmlFor="to-location" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      To
                    </label>
                    <input
                      id="to-location"
                      type="text"
                      placeholder="Enter destination city"
                      className="input"
                      value={toCity}
                      onChange={(e) => {
                        setToCity(e.target.value);
                        setShowToDropdown(true);
                      }}
                      onFocus={() => setShowToDropdown(true)}
                    />
                    {showToDropdown && (
                      <div className="absolute z-10 w-full mt-1 bg-white dark:bg-gray-800 rounded-md shadow-lg max-h-60 overflow-auto">
                        {filteredToCities.length > 0 ? (
                          filteredToCities.map((city) => (
                            <div
                              key={city.id}
                              className="px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-primary-50 dark:hover:bg-gray-700 cursor-pointer"
                              onClick={() => handleToCitySelect(city.name)}
                            >
                              {city.name}
                            </div>
                          ))
                        ) : (
                          <div className="px-4 py-2 text-sm text-gray-500 dark:text-gray-400">
                            No cities found
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  
                  {/* Date Picker */}
                  <div className="relative">
                    <label htmlFor="departure-date" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Departure Date
                    </label>
                    <div className="relative">
                      <input
                        id="departure-date"
                        type="date"
                        className="input pr-10"
                        value={departureDate}
                        onChange={(e) => setDepartureDate(e.target.value)}
                        min={new Date().toISOString().split('T')[0]}
                        onClick={(e) => {
                          e.preventDefault();
                          setShowCalendar(!showCalendar);
                        }}
                      />
                      <CalendarDays 
                        size={18} 
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 dark:text-gray-400 pointer-events-none" 
                      />
                    </div>
                    
                    {showCalendar && (
                      <div className="absolute right-0 z-10 mt-1 bg-white dark:bg-gray-800 rounded-md shadow-lg p-4 w-64">
                        <div className="grid grid-cols-3 gap-2">
                          {nextFifteenDays.map((day, index) => (
                            <button
                              key={index}
                              className={`text-sm p-2 text-center rounded-md transition-colors ${
                                departureDate === day.date.toISOString().split('T')[0]
                                  ? 'bg-primary-100 text-primary-800 dark:bg-primary-900 dark:text-primary-200'
                                  : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                              }`}
                              onClick={() => handleDateSelect(day.date)}
                            >
                              {day.formatted}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                
                {/* Search Button */}
                <button
                  type="button"
                  className="btn btn-lg btn-primary w-full mt-2"
                  onClick={handleSearch}
                  disabled={!fromCity || !toCity || !departureDate}
                >
                  Search Buses
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;