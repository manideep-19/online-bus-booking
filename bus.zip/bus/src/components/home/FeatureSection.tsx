import React from 'react';
import { Wifi, Coffee, Clock, Shield, Award, Map } from 'lucide-react';

interface FeatureProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const Feature: React.FC<FeatureProps> = ({ icon, title, description }) => {
  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 hover:shadow-md transition-shadow duration-300">
      <div className="h-12 w-12 flex items-center justify-center rounded-full bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400 mb-4">
        {icon}
      </div>
      <h3 className="text-lg font-semibold mb-2 text-gray-900 dark:text-white">{title}</h3>
      <p className="text-gray-600 dark:text-gray-400">{description}</p>
    </div>
  );
};

const FeatureSection: React.FC = () => {
  const features = [
    {
      icon: <Award size={24} />,
      title: "Premium Comfort",
      description: "Enjoy reclining seats, ample legroom, and climate control for a first-class experience."
    },
    {
      icon: <Wifi size={24} />,
      title: "Free Wi-Fi",
      description: "Stay connected with complimentary high-speed Internet access throughout your journey."
    },
    {
      icon: <Shield size={24} />,
      title: "Safe Travel",
      description: "Travel with confidence with our rigorous safety protocols and professional drivers."
    },
    {
      icon: <Clock size={24} />,
      title: "On-Time Service",
      description: "Count on our punctual departures and arrivals to keep your schedule on track."
    },
    {
      icon: <Map size={24} />,
      title: "Extensive Network",
      description: "Choose from our vast network of routes connecting all major cities and destinations."
    },
    {
      icon: <Coffee size={24} />,
      title: "Onboard Amenities",
      description: "Complimentary refreshments and entertainment options to enjoy during your ride."
    },
  ];

  return (
    <section className="py-16 bg-gray-50 dark:bg-gray-900">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="mb-4 text-gray-900 dark:text-white">Why Choose RideEase?</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Experience the perfect blend of comfort, convenience, and reliability with our premium bus service.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Feature
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeatureSection;