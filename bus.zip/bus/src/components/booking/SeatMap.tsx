import React, { useState } from 'react';
import { cn } from '../../lib/utils';

interface SeatProps {
  id: string;
  number: string;
  isAvailable: boolean;
  price: number;
  onClick: (id: string, isSelected: boolean) => void;
  isSelected: boolean;
}

const Seat: React.FC<SeatProps> = ({ id, number, isAvailable, price, onClick, isSelected }) => {
  return (
    <button
      disabled={!isAvailable}
      onClick={() => onClick(id, !isSelected)}
      className={cn(
        'w-12 h-12 rounded flex flex-col items-center justify-center text-xs font-medium transition-colors relative',
        isAvailable && !isSelected && 'border-2 border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 hover:border-primary-400 dark:hover:border-primary-600',
        isSelected && 'border-2 border-primary-600 bg-primary-50 dark:bg-primary-900 dark:border-primary-400',
        !isAvailable && 'bg-gray-200 dark:bg-gray-700 cursor-not-allowed opacity-50',
      )}
      aria-label={`Seat ${number} ${isAvailable ? 'available' : 'unavailable'}`}
    >
      <span className={cn(
        'text-gray-700 dark:text-gray-300',
        isSelected && 'text-primary-700 dark:text-primary-300'
      )}>
        {number}
      </span>
      {isSelected && (
        <div className="absolute -top-1 -right-1 w-3 h-3 bg-primary-600 dark:bg-primary-400 rounded-full"></div>
      )}
    </button>
  );
};

interface SeatMapProps {
  busId: string;
  onSeatSelectionChange: (seats: string[], totalPrice: number) => void;
  seatPrice: number;
}

const SeatMap: React.FC<SeatMapProps> = ({ busId, onSeatSelectionChange, seatPrice }) => {
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  
  // Mock seat data - in a real app, this would come from an API
  const seatsData = Array.from({ length: 40 }, (_, i) => ({
    id: `${busId}-seat-${i + 1}`,
    number: (i + 1).toString(),
    isAvailable: Math.random() > 0.3, // Randomly make some seats unavailable
  }));

  const handleSeatClick = (seatId: string, isSelected: boolean) => {
    let newSelectedSeats;
    
    if (isSelected) {
      newSelectedSeats = [...selectedSeats, seatId];
    } else {
      newSelectedSeats = selectedSeats.filter(id => id !== seatId);
    }
    
    setSelectedSeats(newSelectedSeats);
    onSeatSelectionChange(newSelectedSeats, newSelectedSeats.length * seatPrice);
  };

  return (
    <div className="p-6 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800">
      <div className="mb-6">
        <div className="flex justify-center mb-8">
          <div className="w-3/4 h-10 bg-gray-300 dark:bg-gray-700 rounded-lg flex items-center justify-center text-gray-600 dark:text-gray-300 text-sm">
            Driver
          </div>
        </div>
        
        <div className="grid grid-cols-4 gap-3">
          {seatsData.map((seat) => (
            <Seat
              key={seat.id}
              id={seat.id}
              number={seat.number}
              isAvailable={seat.isAvailable}
              price={seatPrice}
              onClick={handleSeatClick}
              isSelected={selectedSeats.includes(seat.id)}
            />
          ))}
        </div>
      </div>
      
      <div className="mt-6 border-t border-gray-200 dark:border-gray-700 pt-4">
        <div className="flex justify-between mb-2">
          <div className="flex items-center">
            <div className="w-4 h-4 rounded bg-white dark:bg-gray-800 border-2 border-gray-300 dark:border-gray-700 mr-2"></div>
            <span className="text-sm text-gray-600 dark:text-gray-400">Available</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 rounded bg-primary-50 dark:bg-primary-900 border-2 border-primary-600 dark:border-primary-400 mr-2"></div>
            <span className="text-sm text-gray-600 dark:text-gray-400">Selected</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 rounded bg-gray-200 dark:bg-gray-700 mr-2 opacity-50"></div>
            <span className="text-sm text-gray-600 dark:text-gray-400">Unavailable</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SeatMap;