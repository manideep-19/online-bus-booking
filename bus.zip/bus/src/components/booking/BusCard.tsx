import React from 'react';
import { Clock, Wifi, ChevronRight, Coffee, MonitorSmartphone, Star } from 'lucide-react';
import { formatTime, formatPrice } from '../../lib/utils';

interface BusCardProps {
  id: string;
  busName: string;
  busType: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  price: number;
  seatsAvailable: number;
  rating: number;
  amenities: string[];
  onSelectBus: (id: string) => void;
}

const BusCard: React.FC<BusCardProps> = ({
  id,
  busName,
  busType,
  departureTime,
  arrivalTime,
  duration,
  price,
  seatsAvailable,
  rating,
  amenities,
  onSelectBus,
}) => {
  const renderAmenityIcon = (amenity: string) => {
    switch (amenity) {
      case 'wifi':
        return <Wifi size={16} className="text-gray-500 dark:text-gray-400" />;
      case 'refreshments':
        return <Coffee size={16} className="text-gray-500 dark:text-gray-400" />;
      case 'entertainment':
        return <MonitorSmartphone size={16} className="text-gray-500 dark:text-gray-400" />;
      default:
        return null;
    }
  };

  return (
    <div className="card hover:border-primary-200 dark:hover:border-primary-800 transition-colors duration-200">
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white">{busName}</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">{busType}</p>
          </div>
          <div className="flex items-center bg-primary-50 dark:bg-primary-950 px-2 py-1 rounded text-sm">
            <Star size={14} className="text-orange-500 fill-orange-500 mr-1" />
            <span className="font-medium text-gray-800 dark:text-gray-200">{rating.toFixed(1)}</span>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 py-4 border-y border-gray-100 dark:border-gray-800">
          <div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">Departure</p>
            <p className="text-xl font-bold text-gray-900 dark:text-white">{formatTime(departureTime)}</p>
          </div>

          <div className="flex flex-col items-center justify-center">
            <div className="relative w-full h-0.5 bg-gray-200 dark:bg-gray-700 my-1">
              <div className="absolute top-1/2 left-0 w-1.5 h-1.5 -mt-0.5 rounded-full bg-primary-600 dark:bg-primary-500"></div>
              <div className="absolute top-1/2 right-0 w-1.5 h-1.5 -mt-0.5 rounded-full bg-primary-600 dark:bg-primary-500"></div>
            </div>
            <div className="flex items-center mt-1">
              <Clock size={14} className="text-gray-500 dark:text-gray-400 mr-1" />
              <span className="text-xs text-gray-600 dark:text-gray-300">{duration}</span>
            </div>
          </div>

          <div className="text-right">
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">Arrival</p>
            <p className="text-xl font-bold text-gray-900 dark:text-white">{formatTime(arrivalTime)}</p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mt-4 gap-4">
          <div>
            <div className="flex items-center space-x-3 mb-2">
              {amenities.map((amenity, index) => (
                <div key={index} className="flex items-center" title={amenity}>
                  {renderAmenityIcon(amenity)}
                </div>
              ))}
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-300">
              <span className={seatsAvailable < 5 ? 'text-orange-600 dark:text-orange-400 font-medium' : ''}>
                {seatsAvailable} seats available
              </span>
            </p>
          </div>

          <div className="w-full sm:w-auto">
            <div className="flex flex-col sm:items-end mb-2">
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{formatPrice(price)}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">per person</p>
            </div>
            <button
              onClick={() => onSelectBus(id)}
              className="w-full sm:w-auto btn btn-md btn-primary flex items-center justify-center"
            >
              Select Seats
              <ChevronRight size={16} className="ml-1" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BusCard;