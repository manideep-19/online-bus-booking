import React, { useState, useEffect } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft, Info, CreditCard, Check, AlertTriangle } from 'lucide-react';
import SeatMap from '../components/booking/SeatMap';
import { useAuthStore } from '../store/authStore';
import { useBookingStore } from '../store/bookingStore';
import { formatDate, formatTime, formatPrice } from '../lib/utils';
import { toast } from 'sonner';

interface LocationState {
  fromCity: string;
  toCity: string;
  departureDate: string;
  busId: string;
}

interface Bus {
  id: string;
  name: string;
  type: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  price: number;
}

const BookingPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const location = useLocation();
  const navigate = useNavigate();
  const state = location.state as LocationState;
  const { isAuthenticated, user } = useAuthStore();
  const { createBooking } = useBookingStore();
  
  const [bus, setBus] = useState<Bus | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [totalPrice, setTotalPrice] = useState<number>(0);
  const [step, setStep] = useState<number>(1);
  const [paymentMethod, setPaymentMethod] = useState<string>('credit_card');
  const [contactInfo, setContactInfo] = useState({
    firstName: user?.first_name || '',
    lastName: user?.last_name || '',
    email: user?.email || '',
    phone: user?.phone_number || '',
  });
  const [cardInfo, setCardInfo] = useState({
    cardNumber: '',
    cardHolder: '',
    expiryDate: '',
    cvv: '',
  });
  const [bookingConfirmed, setBookingConfirmed] = useState<boolean>(false);
  const [bookingId, setBookingId] = useState<string | null>(null);
  
  useEffect(() => {
    if (!id) return;
    
    // Mock API call to get bus details
    setTimeout(() => {
      // This would be an API call in a real application
      const mockBus: Bus = {
        id: id,
        name: 'Express Liner',
        type: 'Luxury',
        departureTime: '2023-10-15T08:00:00',
        arrivalTime: '2023-10-15T12:30:00',
        duration: '4h 30m',
        price: 45.99,
      };
      
      setBus(mockBus);
      setLoading(false);
    }, 1000);
  }, [id]);
  
  const handleSeatSelectionChange = (seats: string[], price: number) => {
    setSelectedSeats(seats);
    setTotalPrice(price);
  };
  
  const handleContactInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setContactInfo({
      ...contactInfo,
      [e.target.name]: e.target.value,
    });
  };
  
  const handleCardInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCardInfo({
      ...cardInfo,
      [e.target.name]: e.target.value,
    });
  };
  
  const validateSeatSelection = (): boolean => {
    if (selectedSeats.length === 0) {
      toast.error('Please select at least one seat to continue.');
      return false;
    }
    return true;
  };
  
  const validateContactInfo = (): boolean => {
    const { firstName, lastName, email, phone } = contactInfo;
    if (!firstName || !lastName || !email || !phone) {
      toast.error('Please fill in all contact information fields.');
      return false;
    }
    
    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      toast.error('Please enter a valid email address.');
      return false;
    }
    
    return true;
  };
  
  const validatePaymentInfo = (): boolean => {
    const { cardNumber, cardHolder, expiryDate, cvv } = cardInfo;
    
    if (paymentMethod === 'credit_card') {
      if (!cardNumber || !cardHolder || !expiryDate || !cvv) {
        toast.error('Please fill in all payment information fields.');
        return false;
      }
      
      // Basic credit card validation
      if (!/^\d{16}$/.test(cardNumber.replace(/\s/g, ''))) {
        toast.error('Please enter a valid 16-digit card number.');
        return false;
      }
      
      // Basic expiry date validation (MM/YY)
      if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(expiryDate)) {
        toast.error('Please enter a valid expiry date (MM/YY).');
        return false;
      }
      
      // Basic CVV validation
      if (!/^\d{3,4}$/.test(cvv)) {
        toast.error('Please enter a valid CVV code.');
        return false;
      }
    }
    
    return true;
  };
  
  const handleContinue = () => {
    if (step === 1 && validateSeatSelection()) {
      setStep(2);
    } else if (step === 2 && validateContactInfo()) {
      setStep(3);
    }
  };
  
  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    } else {
      navigate(-1);
    }
  };
  
  const handleSubmit = async () => {
    if (!validatePaymentInfo()) return;
    
    try {
      setLoading(true);
      
      // In a real app, you would process payment here
      
      // Create booking in the database
      if (isAuthenticated && user && bus) {
        const bookingDetails = {
          userId: user.id,
          scheduleId: bus.id,
          seatNumbers: selectedSeats,
          totalPrice,
          status: 'confirmed' as const,
          bookingDate: new Date().toISOString(),
        };
        
        const bookingId = await createBooking(bookingDetails);
        
        if (bookingId) {
          setBookingId(bookingId);
          setBookingConfirmed(true);
          setStep(4);
        } else {
          toast.error('Failed to create booking. Please try again.');
        }
      } else {
        // Demo mode - just show confirmation
        setBookingConfirmed(true);
        setBookingId('DEMO12345');
        setStep(4);
      }
    } catch (error) {
      toast.error('An error occurred during the booking process.');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };
  
  const getStepTitle = (): string => {
    switch (step) {
      case 1: return 'Select Seats';
      case 2: return 'Contact Information';
      case 3: return 'Payment Details';
      case 4: return 'Booking Confirmation';
      default: return '';
    }
  };
  
  if (loading && !bus) {
    return (
      <div className="container py-16 flex justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600" />
      </div>
    );
  }
  
  if (!bus) {
    return (
      <div className="container py-16">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8 text-center">
          <AlertTriangle size={48} className="mx-auto text-error-500 mb-4" />
          <h2 className="text-2xl font-bold mb-4">Bus Not Found</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            We couldn't find the bus you're looking for. It may have been removed or the link is invalid.
          </p>
          <button
            onClick={() => navigate('/')}
            className="btn btn-md btn-primary"
          >
            Back to Home
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-gray-50 dark:bg-gray-900 py-8">
      <div className="container">
        <button
          onClick={handleBack}
          className="flex items-center text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 mb-4"
          disabled={loading}
        >
          <ArrowLeft size={16} className="mr-1" />
          Back
        </button>
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
          {/* Header */}
          <div className="p-6 bg-primary-50 dark:bg-primary-900/20 border-b border-gray-200 dark:border-gray-700">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h1 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                  {getStepTitle()}
                </h1>
                <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <span className="mr-1">{state?.fromCity || 'From'}</span>
                  <ArrowLeft className="rotate-180 mx-1 h-3 w-3" />
                  <span>{state?.toCity || 'To'}</span>
                  <span className="mx-2">•</span>
                  <span>{formatDate(state?.departureDate || new Date().toISOString())}</span>
                </div>
              </div>
              
              {step < 4 && (
                <div className="flex items-center space-x-2">
                  {[1, 2, 3].map((s) => (
                    <div
                      key={s}
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${
                        s === step
                          ? 'bg-primary-600 text-white'
                          : s < step
                          ? 'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-300'
                          : 'bg-gray-200 text-gray-500 dark:bg-gray-700 dark:text-gray-400'
                      }`}
                    >
                      {s}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          
          <div className="p-6">
            {/* Step 1: Seat Selection */}
            {step === 1 && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">
                    Select Your Seats
                  </h3>
                  <SeatMap
                    busId={bus.id}
                    onSeatSelectionChange={handleSeatSelectionChange}
                    seatPrice={bus.price}
                  />
                </div>
                
                <div>
                  <div className="bg-gray-50 dark:bg-gray-900 rounded-xl p-6 sticky top-20">
                    <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">
                      Trip Summary
                    </h3>
                    
                    <div className="space-y-4">
                      <div className="flex justify-between pb-4 border-b border-gray-200 dark:border-gray-700">
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">{bus.name}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{bus.type}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-gray-900 dark:text-white">{formatTime(bus.departureTime)}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{bus.duration}</p>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-2">
                          <span className="text-gray-600 dark:text-gray-400">Seats Selected:</span>
                          <span className="font-medium text-gray-900 dark:text-white">
                            {selectedSeats.length > 0 
                              ? selectedSeats.map(s => s.split('-')[2]).join(', ')
                              : 'None'}
                          </span>
                        </div>
                        
                        <div className="flex justify-between mb-2">
                          <span className="text-gray-600 dark:text-gray-400">Price per seat:</span>
                          <span className="font-medium text-gray-900 dark:text-white">
                            {formatPrice(bus.price)}
                          </span>
                        </div>
                        
                        <div className="flex justify-between mb-4">
                          <span className="text-gray-600 dark:text-gray-400">Number of seats:</span>
                          <span className="font-medium text-gray-900 dark:text-white">
                            {selectedSeats.length}
                          </span>
                        </div>
                        
                        <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
                          <div className="flex justify-between">
                            <span className="font-semibold text-gray-900 dark:text-white">Total:</span>
                            <span className="font-bold text-gray-900 dark:text-white">
                              {formatPrice(totalPrice)}
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <button
                        onClick={handleContinue}
                        disabled={selectedSeats.length === 0}
                        className="w-full btn btn-lg btn-primary mt-4"
                      >
                        Continue to Contact Info
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {/* Step 2: Contact Information */}
            {step === 2 && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">
                    Contact Information
                  </h3>
                  
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          First Name *
                        </label>
                        <input
                          type="text"
                          id="firstName"
                          name="firstName"
                          value={contactInfo.firstName}
                          onChange={handleContactInfoChange}
                          className="input"
                          required
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Last Name *
                        </label>
                        <input
                          type="text"
                          id="lastName"
                          name="lastName"
                          value={contactInfo.lastName}
                          onChange={handleContactInfoChange}
                          className="input"
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Email Address *
                        </label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={contactInfo.email}
                          onChange={handleContactInfoChange}
                          className="input"
                          required
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Phone Number *
                        </label>
                        <input
                          type="tel"
                          id="phone"
                          name="phone"
                          value={contactInfo.phone}
                          onChange={handleContactInfoChange}
                          className="input"
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="flex items-start mt-4">
                      <Info size={16} className="text-primary-600 dark:text-primary-400 mr-2 mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Your ticket and booking confirmation will be sent to this email address.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div>
                  <div className="bg-gray-50 dark:bg-gray-900 rounded-xl p-6 sticky top-20">
                    <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">
                      Trip Summary
                    </h3>
                    
                    <div className="space-y-4">
                      <div className="flex justify-between pb-4 border-b border-gray-200 dark:border-gray-700">
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">{bus.name}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{bus.type}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-gray-900 dark:text-white">{formatTime(bus.departureTime)}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{bus.duration}</p>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-2">
                          <span className="text-gray-600 dark:text-gray-400">Seats:</span>
                          <span className="font-medium text-gray-900 dark:text-white">
                            {selectedSeats.map(s => s.split('-')[2]).join(', ')}
                          </span>
                        </div>
                        
                        <div className="border-t border-gray-200 dark:border-gray-700 pt-4 mt-4">
                          <div className="flex justify-between">
                            <span className="font-semibold text-gray-900 dark:text-white">Total:</span>
                            <span className="font-bold text-gray-900 dark:text-white">
                              {formatPrice(totalPrice)}
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <button
                        onClick={handleContinue}
                        className="w-full btn btn-lg btn-primary mt-4"
                      >
                        Continue to Payment
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {/* Step 3: Payment */}
            {step === 3 && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">
                    Payment Method
                  </h3>
                  
                  <div className="space-y-6">
                    <div className="flex space-x-4">
                      <label className="flex items-center space-x-2 p-4 border rounded-lg border-gray-200 dark:border-gray-700 cursor-pointer bg-white dark:bg-gray-800 relative">
                        <input
                          type="radio"
                          name="payment-method"
                          value="credit_card"
                          checked={paymentMethod === 'credit_card'}
                          onChange={() => setPaymentMethod('credit_card')}
                          className="h-4 w-4 text-primary-600 dark:text-primary-400"
                        />
                        <span className="text-gray-900 dark:text-white font-medium">Credit Card</span>
                        <CreditCard size={20} className="ml-2 text-gray-500" />
                      </label>
                    </div>
                    
                    {paymentMethod === 'credit_card' && (
                      <div className="space-y-4 animate-fade-in">
                        <div>
                          <label htmlFor="cardNumber" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Card Number
                          </label>
                          <input
                            type="text"
                            id="cardNumber"
                            name="cardNumber"
                            placeholder="1234 5678 9012 3456"
                            value={cardInfo.cardNumber}
                            onChange={handleCardInfoChange}
                            className="input"
                            maxLength={19}
                          />
                        </div>
                        
                        <div>
                          <label htmlFor="cardHolder" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Cardholder Name
                          </label>
                          <input
                            type="text"
                            id="cardHolder"
                            name="cardHolder"
                            placeholder="John Doe"
                            value={cardInfo.cardHolder}
                            onChange={handleCardInfoChange}
                            className="input"
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label htmlFor="expiryDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                              Expiry Date (MM/YY)
                            </label>
                            <input
                              type="text"
                              id="expiryDate"
                              name="expiryDate"
                              placeholder="MM/YY"
                              value={cardInfo.expiryDate}
                              onChange={handleCardInfoChange}
                              className="input"
                              maxLength={5}
                            />
                          </div>
                          
                          <div>
                            <label htmlFor="cvv" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                              CVV
                            </label>
                            <input
                              type="text"
                              id="cvv"
                              name="cvv"
                              placeholder="123"
                              value={cardInfo.cvv}
                              onChange={handleCardInfoChange}
                              className="input"
                              maxLength={4}
                            />
                          </div>
                        </div>
                      </div>
                    )}
                    
                    <div className="flex items-start mt-4">
                      <Info size={16} className="text-primary-600 dark:text-primary-400 mr-2 mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        This is a demo application. No actual payment will be processed, and you can use any test data for the payment fields.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div>
                  <div className="bg-gray-50 dark:bg-gray-900 rounded-xl p-6 sticky top-20">
                    <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">
                      Trip Summary
                    </h3>
                    
                    <div className="space-y-4">
                      <div className="flex justify-between pb-4 border-b border-gray-200 dark:border-gray-700">
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">{bus.name}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{bus.type}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-gray-900 dark:text-white">{formatTime(bus.departureTime)}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{bus.duration}</p>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-2">
                          <span className="text-gray-600 dark:text-gray-400">Seats:</span>
                          <span className="font-medium text-gray-900 dark:text-white">
                            {selectedSeats.map(s => s.split('-')[2]).join(', ')}
                          </span>
                        </div>
                        
                        <div className="flex justify-between mb-2">
                          <span className="text-gray-600 dark:text-gray-400">Passenger:</span>
                          <span className="font-medium text-gray-900 dark:text-white">
                            {contactInfo.firstName} {contactInfo.lastName}
                          </span>
                        </div>
                        
                        <div className="border-t border-gray-200 dark:border-gray-700 pt-4 mt-4">
                          <div className="flex justify-between">
                            <span className="font-semibold text-gray-900 dark:text-white">Total:</span>
                            <span className="font-bold text-gray-900 dark:text-white">
                              {formatPrice(totalPrice)}
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <button
                        onClick={handleSubmit}
                        disabled={loading}
                        className="w-full btn btn-lg btn-primary mt-4 flex items-center justify-center"
                      >
                        {loading ? (
                          <>
                            <span className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                            Processing...
                          </>
                        ) : (
                          'Confirm Booking'
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {/* Step 4: Confirmation */}
            {step === 4 && bookingConfirmed && (
              <div className="max-w-2xl mx-auto py-8 text-center">
                <div className="mb-8">
                  <div className="w-16 h-16 bg-success-50 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Check size={32} className="text-success-500" />
                  </div>
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                    Booking Confirmed!
                  </h2>
                  <p className="text-gray-600 dark:text-gray-400">
                    Your booking has been confirmed. We've sent the details to your email.
                  </p>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-900 rounded-xl p-6 mb-8">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      Booking Details
                    </h3>
                    <span className="px-3 py-1 bg-success-50 text-success-700 dark:bg-success-900 dark:text-success-300 text-xs font-medium rounded-full">
                      Confirmed
                    </span>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Booking ID</p>
                        <p className="font-medium text-gray-900 dark:text-white">{bookingId}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Booking Date</p>
                        <p className="font-medium text-gray-900 dark:text-white">{formatDate(new Date().toISOString())}</p>
                      </div>
                    </div>
                    
                    <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                      <div className="flex justify-between mb-2">
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">{state?.fromCity || 'Departure'}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{formatTime(bus.departureTime)}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-gray-900 dark:text-white">{state?.toCity || 'Arrival'}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{formatTime(bus.arrivalTime)}</p>
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center py-2">
                        <p className="text-sm text-gray-500 dark:text-gray-400">Bus</p>
                        <p className="font-medium text-gray-900 dark:text-white">{bus.name} ({bus.type})</p>
                      </div>
                      
                      <div className="flex justify-between items-center py-2">
                        <p className="text-sm text-gray-500 dark:text-gray-400">Passenger</p>
                        <p className="font-medium text-gray-900 dark:text-white">
                          {contactInfo.firstName} {contactInfo.lastName}
                        </p>
                      </div>
                      
                      <div className="flex justify-between items-center py-2">
                        <p className="text-sm text-gray-500 dark:text-gray-400">Seats</p>
                        <p className="font-medium text-gray-900 dark:text-white">
                          {selectedSeats.map(s => s.split('-')[2]).join(', ')}
                        </p>
                      </div>
                      
                      <div className="flex justify-between items-center py-2">
                        <p className="text-sm text-gray-500 dark:text-gray-400">Total Amount</p>
                        <p className="font-bold text-gray-900 dark:text-white">
                          {formatPrice(totalPrice)}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <button
                    onClick={() => navigate('/dashboard')}
                    className="btn btn-md btn-primary"
                  >
                    Go to My Bookings
                  </button>
                  
                  <button
                    onClick={() => navigate('/')}
                    className="btn btn-md btn-secondary"
                  >
                    Back to Home
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingPage;