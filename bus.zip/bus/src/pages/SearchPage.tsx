import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft, Filter, RefreshCw, Calendar, Clock, Bus } from 'lucide-react';
import BusCard from '../components/booking/BusCard';
import { formatDate } from '../lib/utils';

interface LocationState {
  fromCity: string;
  toCity: string;
  departureDate: string;
}

interface BusData {
  id: string;
  busName: string;
  busType: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  price: number;
  seatsAvailable: number;
  rating: number;
  amenities: string[];
}

const SearchPage: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const state = location.state as LocationState;
  
  const [fromCity, setFromCity] = useState<string>('');
  const [toCity, setToCity] = useState<string>('');
  const [departureDate, setDepartureDate] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [busResults, setBusResults] = useState<BusData[]>([]);
  const [showFilters, setShowFilters] = useState<boolean>(false);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 2000]);
  const [departureTimeRange, setDepartureTimeRange] = useState<string[]>([]);
  const [busTypes, setBusTypes] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<string>('price');
  
  useEffect(() => {
    if (state) {
      setFromCity(state.fromCity);
      setToCity(state.toCity);
      setDepartureDate(state.departureDate);
    } else {
      const params = new URLSearchParams(location.search);
      setFromCity(params.get('from') || '');
      setToCity(params.get('to') || '');
      setDepartureDate(params.get('date') || new Date().toISOString().split('T')[0]);
    }
    
    setTimeout(() => {
      const mockBusData: BusData[] = [
        {
          id: '1',
          busName: 'IndiGo Express',
          busType: 'Luxury',
          departureTime: '2023-10-15T08:00:00',
          arrivalTime: '2023-10-15T12:30:00',
          duration: '4h 30m',
          price: 1299.99,
          seatsAvailable: 12,
          rating: 4.7,
          amenities: ['wifi', 'refreshments', 'entertainment'],
        },
        {
          id: '2',
          busName: 'City Link',
          busType: 'Standard',
          departureTime: '2023-10-15T09:15:00',
          arrivalTime: '2023-10-15T14:00:00',
          duration: '4h 45m',
          price: 899.50,
          seatsAvailable: 8,
          rating: 4.2,
          amenities: ['wifi'],
        },
        {
          id: '3',
          busName: 'Royal Travels',
          busType: 'Premium',
          departureTime: '2023-10-15T10:30:00',
          arrivalTime: '2023-10-15T15:00:00',
          duration: '4h 30m',
          price: 1499.00,
          seatsAvailable: 4,
          rating: 4.8,
          amenities: ['wifi', 'refreshments', 'entertainment'],
        },
        {
          id: '4',
          busName: 'Metro Connect',
          busType: 'Economy',
          departureTime: '2023-10-15T12:00:00',
          arrivalTime: '2023-10-15T16:45:00',
          duration: '4h 45m',
          price: 699.00,
          seatsAvailable: 15,
          rating: 3.9,
          amenities: ['wifi'],
        },
        {
          id: '5',
          busName: 'Luxury Liner',
          busType: 'Premium',
          departureTime: '2023-10-15T14:30:00',
          arrivalTime: '2023-10-15T19:00:00',
          duration: '4h 30m',
          price: 1599.00,
          seatsAvailable: 7,
          rating: 4.9,
          amenities: ['wifi', 'refreshments', 'entertainment'],
        },
      ];
      
      setBusResults(mockBusData);
      setLoading(false);
    }, 1500);
  }, [location.search, state]);
  
  const handleSelectBus = (busId: string) => {
    navigate(`/booking/${busId}`, {
      state: {
        fromCity,
        toCity,
        departureDate,
        busId,
      }
    });
  };
  
  const toggleFilters = () => {
    setShowFilters(!showFilters);
  };
  
  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSortBy(e.target.value);
    
    let sortedResults = [...busResults];
    switch (e.target.value) {
      case 'price':
        sortedResults.sort((a, b) => a.price - b.price);
        break;
      case 'departure':
        sortedResults.sort((a, b) => new Date(a.departureTime).getTime() - new Date(b.departureTime).getTime());
        break;
      case 'duration':
        sortedResults.sort((a, b) => {
          const aDuration = parseInt(a.duration.split('h')[0]);
          const bDuration = parseInt(b.duration.split('h')[0]);
          return aDuration - bDuration;
        });
        break;
      case 'rating':
        sortedResults.sort((a, b) => b.rating - a.rating);
        break;
      default:
        break;
    }
    
    setBusResults(sortedResults);
  };
  
  return (
    <div className="bg-gray-50 dark:bg-gray-900 py-8">
      <div className="container">
        <div className="mb-8">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 mb-4"
          >
            <ArrowLeft size={16} className="mr-1" />
            Back
          </button>
          
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 sm:p-6 border border-gray-200 dark:border-gray-700">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white mb-2">
                  {fromCity} to {toCity}
                </h1>
                <div className="flex flex-wrap items-center gap-4 text-gray-600 dark:text-gray-400">
                  <div className="flex items-center">
                    <Calendar size={16} className="mr-1" />
                    <span>{departureDate ? formatDate(departureDate) : formatDate(new Date().toISOString())}</span>
                  </div>
                  <div className="flex items-center">
                    <Bus size={16} className="mr-1" />
                    <span>{busResults.length} buses found</span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <button
                  onClick={toggleFilters}
                  className="btn btn-sm btn-secondary flex items-center"
                >
                  <Filter size={16} className="mr-1" />
                  Filters
                </button>
                
                <div className="relative">
                  <select
                    value={sortBy}
                    onChange={handleSortChange}
                    className="input py-1 pr-8 appearance-none cursor-pointer"
                  >
                    <option value="price">Price (Low to High)</option>
                    <option value="departure">Departure Time</option>
                    <option value="duration">Duration</option>
                    <option value="rating">Rating</option>
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-500 dark:text-gray-400">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Filters */}
            {showFilters && (
              <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700 grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Price Range */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Price Range (₹{priceRange[0]} - ₹{priceRange[1]})
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="2000"
                    step="100"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                    className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer"
                  />
                </div>
                
                {/* Departure Time */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Departure Time
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {['Morning', 'Afternoon', 'Evening', 'Night'].map((time) => (
                      <label key={time} className="flex items-center">
                        <input
                          type="checkbox"
                          className="mr-2 h-4 w-4 text-primary-600 dark:text-primary-500 border-gray-300 dark:border-gray-700 rounded"
                          onChange={(e) => {
                            if (e.target.checked) {
                              setDepartureTimeRange([...departureTimeRange, time]);
                            } else {
                              setDepartureTimeRange(departureTimeRange.filter(t => t !== time));
                            }
                          }}
                        />
                        {time}
                      </label>
                    ))}
                  </div>
                </div>
                
                {/* Bus Type */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Bus Type
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {['Luxury', 'Premium', 'Standard', 'Economy'].map((type) => (
                      <label key={type} className="flex items-center">
                        <input
                          type="checkbox"
                          className="mr-2 h-4 w-4 text-primary-600 dark:text-primary-500 border-gray-300 dark:border-gray-700 rounded"
                          onChange={(e) => {
                            if (e.target.checked) {
                              setBusTypes([...busTypes, type]);
                            } else {
                              setBusTypes(busTypes.filter(t => t !== type));
                            }
                          }}
                        />
                        {type}
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {loading ? (
          <div className="flex flex-col items-center justify-center py-12">
            <RefreshCw size={32} className="text-primary-600 dark:text-primary-400 animate-spin mb-4" />
            <p className="text-gray-600 dark:text-gray-400">Finding the best buses for you...</p>
          </div>
        ) : (
          <div className="space-y-4">
            {busResults.length > 0 ? (
              busResults.map((bus) => (
                <BusCard
                  key={bus.id}
                  id={bus.id}
                  busName={bus.busName}
                  busType={bus.busType}
                  departureTime={bus.departureTime}
                  arrivalTime={bus.arrivalTime}
                  duration={bus.duration}
                  price={bus.price}
                  seatsAvailable={bus.seatsAvailable}
                  rating={bus.rating}
                  amenities={bus.amenities}
                  onSelectBus={handleSelectBus}
                />
              ))
            ) : (
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8 text-center">
                <p className="text-lg text-gray-600 dark:text-gray-400 mb-4">
                  No buses found for this route on the selected date.
                </p>
                <button
                  onClick={() => navigate('/')}
                  className="btn btn-md btn-primary"
                >
                  Modify Search
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchPage;