import React from 'react';
import HeroSection from '../components/home/HeroSection';
import FeatureSection from '../components/home/FeatureSection';
import PopularRoutes from '../components/home/PopularRoutes';
import Testimonials from '../components/home/Testimonials';
import AppCTA from '../components/home/AppCTA';

const HomePage: React.FC = () => {
  return (
    <div>
      <HeroSection />
      <FeatureSection />
      <PopularRoutes />
      <Testimonials />
      <AppCTA />
    </div>
  );
};

export default HomePage;