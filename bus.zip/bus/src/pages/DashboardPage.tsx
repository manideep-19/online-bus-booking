import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { useBookingStore } from '../store/bookingStore';
import { 
  Ticket, 
  User, 
  LogOut, 
  Clock, 
  Calendar, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle,
  Printer
} from 'lucide-react';
import { formatDate, formatTime, formatPrice } from '../lib/utils';

interface BookingItem {
  id: string;
  status: string;
  booking_date: string;
  seat_numbers: string[];
  total_price: number;
  schedules: {
    departure_time: string;
    arrival_time: string;
    buses: {
      name: string;
      type: string;
    };
    routes: {
      from_city: string;
      to_city: string;
    };
  };
}

const DashboardPage: React.FC = () => {
  const { isAuthenticated, user, logout } = useAuthStore();
  const { bookingHistory, fetchUserBookings, loading, cancelBooking } = useBookingStore();
  const [activeTab, setActiveTab] = useState<string>('bookings');
  const navigate = useNavigate();
  
  // Sample booking data for demo purposes
  const [mockBookings, setMockBookings] = useState<BookingItem[]>([
    {
      id: 'BK12345',
      status: 'confirmed',
      booking_date: '2023-10-01T10:30:00',
      seat_numbers: ['12', '13'],
      total_price: 91.98,
      schedules: {
        departure_time: '2023-10-15T08:00:00',
        arrival_time: '2023-10-15T12:30:00',
        buses: {
          name: 'Express Liner',
          type: 'Luxury',
        },
        routes: {
          from_city: 'New York',
          to_city: 'Boston',
        },
      },
    },
    {
      id: 'BK12346',
      status: 'confirmed',
      booking_date: '2023-09-28T14:15:00',
      seat_numbers: ['5'],
      total_price: 55.00,
      schedules: {
        departure_time: '2023-10-20T10:30:00',
        arrival_time: '2023-10-20T15:00:00',
        buses: {
          name: 'Royal Travels',
          type: 'Premium',
        },
        routes: {
          from_city: 'Los Angeles',
          to_city: 'San Francisco',
        },
      },
    },
    {
      id: 'BK12347',
      status: 'cancelled',
      booking_date: '2023-09-15T09:45:00',
      seat_numbers: ['8', '9', '10'],
      total_price: 90.00,
      schedules: {
        departure_time: '2023-09-30T12:00:00',
        arrival_time: '2023-09-30T16:45:00',
        buses: {
          name: 'Metro Connect',
          type: 'Economy',
        },
        routes: {
          from_city: 'Chicago',
          to_city: 'Detroit',
        },
      },
    },
  ]);
  
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    
    if (user) {
      fetchUserBookings(user.id);
    }
  }, [isAuthenticated, user, navigate, fetchUserBookings]);
  
  const handleLogout = async () => {
    await logout();
    navigate('/');
  };
  
  const handleCancelBooking = async (bookingId: string) => {
    if (window.confirm('Are you sure you want to cancel this booking?')) {
      try {
        // In a real app, this would call the API to cancel the booking
        // For demo purposes, we'll just update the mock data
        setMockBookings(mockBookings.map(booking => 
          booking.id === bookingId 
            ? { ...booking, status: 'cancelled' } 
            : booking
        ));
      } catch (error) {
        console.error('Error cancelling booking:', error);
      }
    }
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'confirmed':
        return (
          <span className="px-2 py-1 text-xs font-medium rounded-full bg-success-50 text-success-700 dark:bg-success-900/30 dark:text-success-300 flex items-center">
            <CheckCircle2 size={12} className="mr-1" />
            Confirmed
          </span>
        );
      case 'cancelled':
        return (
          <span className="px-2 py-1 text-xs font-medium rounded-full bg-error-50 text-error-700 dark:bg-error-900/30 dark:text-error-300 flex items-center">
            <XCircle size={12} className="mr-1" />
            Cancelled
          </span>
        );
      default:
        return (
          <span className="px-2 py-1 text-xs font-medium rounded-full bg-warning-50 text-warning-700 dark:bg-warning-900/30 dark:text-warning-300 flex items-center">
            <Clock size={12} className="mr-1" />
            Pending
          </span>
        );
    }
  };
  
  return (
    <div className="bg-gray-50 dark:bg-gray-900 py-8">
      <div className="container">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Sidebar */}
            <div className="md:col-span-1">
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
                <div className="flex flex-col items-center text-center mb-6">
                  <div className="w-20 h-20 bg-primary-100 dark:bg-primary-900 rounded-full flex items-center justify-center text-primary-700 dark:text-primary-300 text-2xl font-bold mb-3">
                    {user?.first_name?.[0]}{user?.last_name?.[0] || ''}
                  </div>
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                    {user?.first_name} {user?.last_name}
                  </h2>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {user?.email}
                  </p>
                </div>
                
                <nav className="space-y-1">
                  <button
                    onClick={() => setActiveTab('bookings')}
                    className={`w-full flex items-center px-4 py-3 rounded-lg text-left ${
                      activeTab === 'bookings'
                        ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-300'
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`}
                  >
                    <Ticket size={18} className="mr-3" />
                    My Bookings
                  </button>
                  
                  <button
                    onClick={() => setActiveTab('profile')}
                    className={`w-full flex items-center px-4 py-3 rounded-lg text-left ${
                      activeTab === 'profile'
                        ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-300'
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`}
                  >
                    <User size={18} className="mr-3" />
                    Profile
                  </button>
                  
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center px-4 py-3 rounded-lg text-left text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    <LogOut size={18} className="mr-3" />
                    Logout
                  </button>
                </nav>
              </div>
            </div>
            
            {/* Main Content */}
            <div className="md:col-span-3">
              {/* My Bookings Tab */}
              {activeTab === 'bookings' && (
                <div>
                  <div className="flex justify-between items-center mb-6">
                    <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                      My Bookings
                    </h1>
                    <Link to="/" className="btn btn-sm btn-primary">
                      Book a Trip
                    </Link>
                  </div>
                  
                  {loading ? (
                    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8 text-center border border-gray-200 dark:border-gray-700">
                      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
                      <p className="text-gray-600 dark:text-gray-400">Loading your bookings...</p>
                    </div>
                  ) : mockBookings.length > 0 ? (
                    <div className="space-y-6">
                      {mockBookings.map((booking) => (
                        <div
                          key={booking.id}
                          className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden"
                        >
                          <div className="p-6">
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
                              <div>
                                <div className="flex items-center mb-2">
                                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mr-3">
                                    {booking.schedules.routes.from_city} to {booking.schedules.routes.to_city}
                                  </h3>
                                  {getStatusBadge(booking.status)}
                                </div>
                                
                                <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                                  <Calendar size={16} className="mr-1" />
                                  {formatDate(booking.schedules.departure_time)}
                                  <span className="mx-2">•</span>
                                  <Clock size={16} className="mr-1" />
                                  {formatTime(booking.schedules.departure_time)}
                                </div>
                              </div>
                              
                              <div className="text-right">
                                <p className="text-xs text-gray-500 dark:text-gray-400">
                                  Booking ID: {booking.id}
                                </p>
                                <p className="text-xs text-gray-500 dark:text-gray-400">
                                  Booked on {formatDate(booking.booking_date)}
                                </p>
                              </div>
                            </div>
                            
                            <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div>
                                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Bus</p>
                                  <p className="font-medium text-gray-900 dark:text-white">
                                    {booking.schedules.buses.name} ({booking.schedules.buses.type})
                                  </p>
                                </div>
                                
                                <div>
                                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Seats</p>
                                  <p className="font-medium text-gray-900 dark:text-white">
                                    {booking.seat_numbers.join(', ')}
                                  </p>
                                </div>
                                
                                <div>
                                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Amount Paid</p>
                                  <p className="font-medium text-gray-900 dark:text-white">
                                    {formatPrice(booking.total_price)}
                                  </p>
                                </div>
                              </div>
                            </div>
                            
                            <div className="border-t border-gray-200 dark:border-gray-700 mt-4 pt-4 flex flex-wrap gap-2">
                              {booking.status === 'confirmed' && (
                                <>
                                  <button className="btn btn-sm btn-secondary flex items-center">
                                    <Printer size={16} className="mr-1" />
                                    Print Ticket
                                  </button>
                                  
                                  <button
                                    onClick={() => handleCancelBooking(booking.id)}
                                    className="btn btn-sm btn-outline text-error-600 dark:text-error-400 border-error-200 dark:border-error-800 hover:bg-error-50 dark:hover:bg-error-900/20"
                                  >
                                    Cancel Booking
                                  </button>
                                </>
                              )}
                              
                              <Link to={`/booking/${booking.id}`} className="btn btn-sm btn-outline">
                                View Details
                              </Link>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8 text-center border border-gray-200 dark:border-gray-700">
                      <AlertTriangle size={48} className="mx-auto text-warning-500 mb-4" />
                      <h2 className="text-xl font-semibold mb-2 text-gray-900 dark:text-white">
                        No Bookings Found
                      </h2>
                      <p className="text-gray-600 dark:text-gray-400 mb-6">
                        You haven't made any bookings yet. Start by finding a route and booking your first trip.
                      </p>
                      <Link to="/" className="btn btn-md btn-primary">
                        Book a Trip
                      </Link>
                    </div>
                  )}
                </div>
              )}
              
              {/* Profile Tab */}
              {activeTab === 'profile' && (
                <div>
                  <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                    My Profile
                  </h1>
                  
                  <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
                    <form className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            First Name
                          </label>
                          <input
                            type="text"
                            id="firstName"
                            name="firstName"
                            defaultValue={user?.first_name || ''}
                            className="input"
                          />
                        </div>
                        
                        <div>
                          <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Last Name
                          </label>
                          <input
                            type="text"
                            id="lastName"
                            name="lastName"
                            defaultValue={user?.last_name || ''}
                            className="input"
                          />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Email Address
                          </label>
                          <input
                            type="email"
                            id="email"
                            name="email"
                            defaultValue={user?.email || ''}
                            className="input"
                            disabled
                          />
                          <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                            Email address cannot be changed
                          </p>
                        </div>
                        
                        <div>
                          <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Phone Number
                          </label>
                          <input
                            type="tel"
                            id="phoneNumber"
                            name="phoneNumber"
                            defaultValue={user?.phone_number || ''}
                            className="input"
                          />
                        </div>
                      </div>
                      
                      <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
                        <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">
                          Change Password
                        </h3>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div>
                            <label htmlFor="currentPassword" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                              Current Password
                            </label>
                            <input
                              type="password"
                              id="currentPassword"
                              name="currentPassword"
                              className="input"
                            />
                          </div>
                          
                          <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                              <label htmlFor="newPassword" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                New Password
                              </label>
                              <input
                                type="password"
                                id="newPassword"
                                name="newPassword"
                                className="input"
                              />
                            </div>
                            
                            <div>
                              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                Confirm New Password
                              </label>
                              <input
                                type="password"
                                id="confirmPassword"
                                name="confirmPassword"
                                className="input"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex justify-end">
                        <button
                          type="submit"
                          className="btn btn-md btn-primary"
                        >
                          Save Changes
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;