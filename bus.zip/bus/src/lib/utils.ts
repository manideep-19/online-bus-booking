import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { format, addDays, parse } from 'date-fns';

/**
 * Combines multiple class names using clsx and tailwind-merge
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Formats a date to a readable string
 */
export function formatDate(date: Date | string): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return format(dateObj, 'MMM dd, yyyy');
}

/**
 * Formats a time to a readable string
 */
export function formatTime(time: Date | string): string {
  const timeObj = typeof time === 'string' ? new Date(time) : time;
  return format(timeObj, 'h:mm a');
}

/**
 * Calculate the difference between two dates/times in hours and minutes
 */
export function calculateDuration(start: Date | string, end: Date | string): string {
  const startTime = typeof start === 'string' ? new Date(start) : start;
  const endTime = typeof end === 'string' ? new Date(end) : end;
  
  const diffInMs = endTime.getTime() - startTime.getTime();
  const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60));
  const diffInMinutes = Math.floor((diffInMs % (1000 * 60 * 60)) / (1000 * 60));
  
  return `${diffInHours}h ${diffInMinutes}m`;
}

/**
 * Gets the next 15 days for the date picker
 */
export function getNextFifteenDays(): { date: Date; formatted: string }[] {
  const days = [];
  const today = new Date();
  
  for (let i = 0; i < 15; i++) {
    const date = addDays(today, i);
    days.push({
      date,
      formatted: format(date, 'EEE, MMM d'),
    });
  }
  
  return days;
}

/**
 * Formats price with currency symbol
 */
export function formatPrice(price: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(price);
}