export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          first_name: string | null
          last_name: string | null
          phone_number: string | null
          created_at: string
        }
        Insert: {
          id: string
          email: string
          first_name?: string | null
          last_name?: string | null
          phone_number?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          email?: string
          first_name?: string | null
          last_name?: string | null
          phone_number?: string | null
          created_at?: string
        }
      }
      buses: {
        Row: {
          id: string
          name: string
          bus_number: string
          type: string
          seats_count: number
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          bus_number: string
          type: string
          seats_count: number
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          bus_number?: string
          type?: string
          seats_count?: number
          created_at?: string
        }
      }
      routes: {
        Row: {
          id: string
          from_city: string
          to_city: string
          distance: number
          duration: number
          created_at: string
        }
        Insert: {
          id?: string
          from_city: string
          to_city: string
          distance: number
          duration: number
          created_at?: string
        }
        Update: {
          id?: string
          from_city?: string
          to_city?: string
          distance?: number
          duration?: number
          created_at?: string
        }
      }
      schedules: {
        Row: {
          id: string
          bus_id: string
          route_id: string
          departure_time: string
          arrival_time: string
          price: number
          created_at: string
        }
        Insert: {
          id?: string
          bus_id: string
          route_id: string
          departure_time: string
          arrival_time: string
          price: number
          created_at?: string
        }
        Update: {
          id?: string
          bus_id?: string
          route_id?: string
          departure_time?: string
          arrival_time?: string
          price?: number
          created_at?: string
        }
      }
      bookings: {
        Row: {
          id: string
          user_id: string
          schedule_id: string
          seat_numbers: string[]
          total_price: number
          booking_date: string
          status: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          schedule_id: string
          seat_numbers: string[]
          total_price: number
          booking_date?: string
          status?: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          schedule_id?: string
          seat_numbers?: string[]
          total_price?: number
          booking_date?: string
          status?: string
          created_at?: string
        }
      }
    }
  }
}