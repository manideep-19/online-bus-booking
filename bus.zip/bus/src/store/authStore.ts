import { create } from 'zustand';
import { Session, User as SupaUser } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

export interface UserProfile {
  id: string;
  email: string;
  first_name?: string;
  last_name?: string;
  phone_number?: string;
}

interface AuthState {
  isAuthenticated: boolean;
  user: UserProfile | null;
  loading: boolean;
  error: string | null;

  initialize: () => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, profile: Omit<UserProfile, 'id' | 'email'>) => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (updates: Partial<UserProfile>) => Promise<void>;
}

export const useAuthStore = create<AuthState>((set, get) => {
  let authListener: { unsubscribe: () => void } | null = null;

  async function loadProfile(supaUser: SupaUser) {
    const { data: profile, error } = await supabase
      .from<UserProfile>('users')
      .select('id, email, first_name, last_name, phone_number')
      .eq('id', supaUser.id)
      .maybeSingle();
    if (error) throw error;
    return profile ?? { id: supaUser.id, email: supaUser.email! };
  }

  return {
    isAuthenticated: false,
    user: null,
    loading: false,
    error: null,

    initialize: async () => {
      set({ loading: true, error: null });
      const { data: { session }, error: sessErr } = await supabase.auth.getSession();

      if (sessErr) {
        set({ loading: false, error: sessErr.message });
        return;
      }

      if (session?.user) {
        try {
          const profile = await loadProfile(session.user);
          set({ isAuthenticated: true, user: profile, loading: false });
        } catch (err) {
          set({ loading: false, error: (err as Error).message });
          return;
        }
      } else {
        set({ isAuthenticated: false, user: null, loading: false });
      }

      authListener = supabase.auth.onAuthStateChange(async (_event, newSession: Session | null) => {
        if (newSession?.user) {
          try {
            const profile = await loadProfile(newSession.user);
            set({ isAuthenticated: true, user: profile, error: null });
          } catch (err) {
            set({ error: (err as Error).message });
          }
        } else {
          set({ isAuthenticated: false, user: null });
        }
      });
    },

    login: async (email, password) => {
      set({ loading: true, error: null });
      try {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        if (!data.session) throw new Error('No session returned from Supabase');

        const profile = await loadProfile(data.user!);
        set({ isAuthenticated: true, user: profile, loading: false });
      } catch (err) {
        set({ loading: false, error: (err as Error).message });
        throw err;
      }
    },

    register: async (email, password, profileData) => {
      set({ loading: true, error: null });
      try {
        const { data, error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        const { error: insertErr } = await supabase
          .from('users')
          .insert({ id: data.user!.id, email, ...profileData });
        if (insertErr) throw insertErr;

        const profile = await loadProfile(data.user!);
        set({ isAuthenticated: true, user: profile, loading: false });
      } catch (err) {
        set({ loading: false, error: (err as Error).message });
        throw err;
      }
    },

    logout: async () => {
      await supabase.auth.signOut();
      authListener?.unsubscribe();
      set({ isAuthenticated: false, user: null });
    },

    updateProfile: async (updates) => {
      const current = get().user;
      if (!current) throw new Error('Not authenticated');
      set({ loading: true, error: null });
      try {
        const { error } = await supabase
          .from('users')
          .update(updates)
          .eq('id', current.id);
        if (error) throw error;
        set({ user: { ...current, ...updates }, loading: false });
      } catch (err) {
        set({ loading: false, error: (err as Error).message });
        throw err;
      }
    },
  };
});
