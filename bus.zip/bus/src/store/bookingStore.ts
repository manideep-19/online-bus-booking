import { create } from 'zustand';
import { supabase } from '../lib/supabase';

export interface BookingDetails {
  id?: string;
  userId: string;
  scheduleId: string;
  seatNumbers: string[];
  totalPrice: number;
  status: 'pending' | 'confirmed' | 'cancelled';
  bookingDate: string;
}

interface BookingState {
  currentBooking: BookingDetails | null;
  bookingHistory: BookingDetails[];
  loading: boolean;
  error: string | null;
  
  setCurrentBooking: (booking: BookingDetails | null) => void;
  createBooking: (booking: BookingDetails) => Promise<string | null>;
  fetchUserBookings: (userId: string) => Promise<void>;
  cancelBooking: (bookingId: string) => Promise<void>;
}

export const useBookingStore = create<BookingState>((set, get) => ({
  currentBooking: null,
  bookingHistory: [],
  loading: false,
  error: null,
  
  setCurrentBooking: (booking) => {
    set({ currentBooking: booking });
  },
  
  createBooking: async (booking) => {
    try {
      const user = supabase.auth.user(); // Get the logged-in user

      if (!user) {
        set({ error: 'User must be logged in to make a booking', loading: false });
        return null;
      }

      set({ loading: true, error: null });

      const { data, error } = await supabase
        .from('bookings')
        .insert({
          user_id: user.id,
          schedule_id: booking.scheduleId,
          seat_numbers: booking.seatNumbers,
          total_price: booking.totalPrice,
          status: 'pending',
          booking_date: booking.bookingDate,
        })
        .select()
        .single();

      if (error) throw error;

      set({ 
        currentBooking: data, 
        loading: false 
      });

      return data.id;
    } catch (error) {
      set({ 
        loading: false, 
        error: (error as Error).message || 'An unknown error occurred' 
      });
      return null;
    }
  },
  
  fetchUserBookings: async (userId) => {
    try {
      set({ loading: true, error: null });
      
      const { data, error } = await supabase
        .from('bookings')
        .select(`*,
          schedules:schedule_id (*),
          buses:bus_id (*),
          routes:route_id (*)
        `)
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      set({ 
        bookingHistory: data || [], 
        loading: false 
      });
    } catch (error) {
      set({ 
        loading: false, 
        error: (error as Error).message || 'Failed to fetch bookings' 
      });
    }
  },
  
  cancelBooking: async (bookingId) => {
    try {
      set({ loading: true, error: null });
      
      const { error } = await supabase
        .from('bookings')
        .update({ status: 'cancelled' })
        .eq('id', bookingId);
      
      if (error) throw error;

      // Update booking in history
      const { bookingHistory } = get();
      const updatedHistory = bookingHistory.map(booking => 
        booking.id === bookingId 
          ? { ...booking, status: 'cancelled' as const } 
          : booking
      );
      
      set({ 
        bookingHistory: updatedHistory, 
        loading: false 
      });
    } catch (error) {
      set({ 
        loading: false, 
        error: (error as Error).message || 'Failed to cancel booking' 
      });
    }
  },
}));
