/*
  # Initial Database Schema Setup

  1. New Tables
    - `users` - Stores user profile information
    - `buses` - Stores bus information
    - `routes` - Stores route information
    - `schedules` - Stores schedule information
    - `bookings` - Stores booking information

  2. Security
    - Enable RLS on all tables
    - Add policies to allow authenticated users to read their own data
    - Add policies for CRUD operations
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  first_name TEXT,
  last_name TEXT,
  phone_number TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create buses table
CREATE TABLE IF NOT EXISTS buses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  bus_number TEXT NOT NULL UNIQUE,
  type TEXT NOT NULL,
  seats_count INTEGER NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create routes table
CREATE TABLE IF NOT EXISTS routes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  from_city TEXT NOT NULL,
  to_city TEXT NOT NULL,
  distance NUMERIC NOT NULL,
  duration NUMERIC NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(from_city, to_city)
);

-- Create schedules table
CREATE TABLE IF NOT EXISTS schedules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bus_id UUID NOT NULL REFERENCES buses(id),
  route_id UUID NOT NULL REFERENCES routes(id),
  departure_time TIMESTAMPTZ NOT NULL,
  arrival_time TIMESTAMPTZ NOT NULL,
  price NUMERIC NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create bookings table
CREATE TABLE IF NOT EXISTS bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  schedule_id UUID NOT NULL REFERENCES schedules(id),
  seat_numbers TEXT[] NOT NULL,
  total_price NUMERIC NOT NULL,
  booking_date TIMESTAMPTZ DEFAULT now(),
  status TEXT NOT NULL DEFAULT 'confirmed',
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE buses ENABLE ROW LEVEL SECURITY;
ALTER TABLE routes ENABLE ROW LEVEL SECURITY;
ALTER TABLE schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Policies for users table
CREATE POLICY "Users can read own data" 
  ON users 
  FOR SELECT 
  TO authenticated 
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data" 
  ON users 
  FOR UPDATE 
  TO authenticated 
  USING (auth.uid() = id);

-- Policies for buses table
CREATE POLICY "Anyone can read buses" 
  ON buses 
  FOR SELECT 
  TO anon, authenticated 
  USING (true);

-- Policies for routes table
CREATE POLICY "Anyone can read routes" 
  ON routes 
  FOR SELECT 
  TO anon, authenticated 
  USING (true);

-- Policies for schedules table
CREATE POLICY "Anyone can read schedules" 
  ON schedules 
  FOR SELECT 
  TO anon, authenticated 
  USING (true);

-- Policies for bookings table
CREATE POLICY "Users can read own bookings" 
  ON bookings 
  FOR SELECT 
  TO authenticated 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create bookings" 
  ON bookings 
  FOR INSERT 
  TO authenticated 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own bookings" 
  ON bookings 
  FOR UPDATE 
  TO authenticated 
  USING (auth.uid() = user_id);