/*
  # Seed Data for Bus Booking System

  1. Sample Data
    - Add sample buses
    - Add sample routes
    - Add sample schedules
*/

-- Seed buses
INSERT INTO buses (name, bus_number, type, seats_count)
VALUES
  ('Express Liner', 'EL-1001', 'Luxury', 40),
  ('City Cruiser', 'CC-2001', 'Standard', 36),
  ('Royal Travels', 'RT-3001', 'Premium', 32),
  ('Metro Connect', 'MC-4001', 'Economy', 44),
  ('Luxury Liner', 'LL-5001', 'Premium', 30)
ON CONFLICT (bus_number) DO NOTHING;

-- Seed routes
INSERT INTO routes (from_city, to_city, distance, duration)
VALUES
  ('New York', 'Boston', 350, 4.5),
  ('Los Angeles', 'San Francisco', 380, 6.25),
  ('Chicago', 'Detroit', 280, 5),
  ('Miami', 'Orlando', 235, 3.75),
  ('Seattle', 'Portland', 280, 3),
  ('Atlanta', 'Nashville', 250, 4),
  ('Dallas', 'Houston', 240, 3.5),
  ('Denver', 'Salt Lake City', 500, 7)
ON CONFLICT (from_city, to_city) DO NOTHING;

-- Seed schedules
DO $$
DECLARE
  bus_ids UUID[];
  route_ids UUID[];
  i INTEGER;
BEGIN
  -- Get all bus ids
  SELECT array_agg(id) INTO bus_ids FROM buses;
  
  -- Get all route ids
  SELECT array_agg(id) INTO route_ids FROM routes;
  
  -- Create schedules for routes
  FOR i IN 1..array_length(route_ids, 1) LOOP
    -- Morning schedule
    INSERT INTO schedules (bus_id, route_id, departure_time, arrival_time, price)
    SELECT
      bus_ids[1 + (i % array_length(bus_ids, 1))],
      route_ids[i],
      NOW() + (i || ' days')::INTERVAL + '8 hours'::INTERVAL,
      NOW() + (i || ' days')::INTERVAL + '8 hours'::INTERVAL + ((SELECT duration FROM routes WHERE id = route_ids[i]) || ' hours')::INTERVAL,
      35 + (i * 5)
    ON CONFLICT DO NOTHING;
    
    -- Afternoon schedule
    INSERT INTO schedules (bus_id, route_id, departure_time, arrival_time, price)
    SELECT
      bus_ids[1 + ((i + 2) % array_length(bus_ids, 1))],
      route_ids[i],
      NOW() + (i || ' days')::INTERVAL + '14 hours'::INTERVAL,
      NOW() + (i || ' days')::INTERVAL + '14 hours'::INTERVAL + ((SELECT duration FROM routes WHERE id = route_ids[i]) || ' hours')::INTERVAL,
      40 + (i * 5)
    ON CONFLICT DO NOTHING;
    
    -- Evening schedule
    INSERT INTO schedules (bus_id, route_id, departure_time, arrival_time, price)
    SELECT
      bus_ids[1 + ((i + 3) % array_length(bus_ids, 1))],
      route_ids[i],
      NOW() + (i || ' days')::INTERVAL + '20 hours'::INTERVAL,
      NOW() + (i || ' days')::INTERVAL + '20 hours'::INTERVAL + ((SELECT duration FROM routes WHERE id = route_ids[i]) || ' hours')::INTERVAL,
      45 + (i * 5)
    ON CONFLICT DO NOTHING;
  END LOOP;
END
$$;